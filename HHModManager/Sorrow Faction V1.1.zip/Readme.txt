Created by MagicalStorm
thanks Lyolf for the readme & banner template

==DESCRIPTION==
The Sorrow faction mostly puts emphasis on 'quality over quantity', so it has low weekly growths and a far more expensive tier 6, but boasts higher stats and a ton of abilities

==FEATURES==
6 Heroes
2 Hero Classes
9 Base Faction Units
9 Upgraded Faction Units
5 Neutral Units
1 Projectile

==INSTALLATION==
Unzip the Sorrow folder into Hero's Hour's "mods" folder. Then, inside that same folder, open up "MOD SETTINGS.txt". You should find "LOAD MODS FROM FOLLOWING FOLDERS:" at the very top. Add another line below labeled "Sorrow". Finally, open up the game and enter the options page. From there, switch to the "Game" tab and set mods to enabled then restart the game.

==CHANGELOG==
2022-03-05 V1.1 - Balance Update, wooo
 
Albinos, their variants and Unhooded/Dread Mothers now have Splitting Half
Replaced Dread Mother's Blaster with Long Ranged
Removed Lonestar Splitting, greatly lowered Ticks and Lonestars hp
Replaced Scytodidae's Blaster with Wind Up and Wide Attacks, greatly lowered stats
Peacocks & Sun Dancers now cast Berserk instead of Animate Dead
Lowered Funnel Web's stats and number of abilities
Increased Phantom Goliath's stats
Doubled Dictator/Emperor's prices

2022-02-02 V1.0 - Initial Release (what a date to release on)